var pooh = { 
    character: "Winnie the Pooh",
    south: tigger,
    north: robin,
    west: piglet,
    east: bees,
    greet: function(){
        console.log("Pooh")
    }
};
var tigger = { 
    character: "Tigger",
    north: pooh,
    greet: function(){
        console.log("Ror")
    }
};
var piglet = { 
    character: "Piglet",
    east: pooh,
    north: owl,
    greet: function(){
        console.log("Pig Pig")
    }
};
var bees = {
    character: "Bees",
    west: pooh,
    north: rabbit,
    greet: function(){
        console.log("bzz bzz")
    }
};
var owl = { 
    character: "Owl",
    south: piglet,
    east: robin,
    greet: function(){
        console.log("who who")
    }
};
var robin = {
    character: "Christopher Robin",
    south: pooh,
    north: kanga,
    west: owl,
    east: rabbit,
    greet: function(){
        console.log("Hey I'm Robin")
    }
};
var rabbit = {
    character: "Rabbit",
    south: bees,
    east: gopher,
    west: robin,
    greet: function(){
        console.log("Jump")
    }
};
var gopher = {
    character: "Gopher",
    west: rabbit,
    greet: function(){
        console.log("I dont know who i am!")
    }
};
var kanga = {
    character: "Kanga",
    south: robin,
    north: eeyore,
    greet: function(){
        console.log("Me neither")
    }
};
var eeyore = {
    character: "Eeyore",
    south: kanga,
    east: heff,
    greet: function(){
        console.log("I have no clue either")
    }
};
var heff = {
    character: "Heffalumps",
    west: eeyore,
    greet: function(){
        console.log("Heff!")
    }
}; 

var player = {
    location: tigger,
};

function move(direction){
    if(!player.location[direction]){
        console.log("You can't move this derection");
    }
    else{
        player.location = player.location[direction];
        console.log("You are now at " + player.location.character + "\'s house.");
        player.location.greet();
    }
};


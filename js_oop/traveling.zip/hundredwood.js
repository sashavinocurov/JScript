var pooh = { 
    character: "Winnie the Pooh",
    south: tigger,
    north: robin,
    west: piglet,
    east: bees,
};
var tigger = { 
    character: "Tigger",
    north: pooh,
};
var piglet = { 
    character: "Piglet",
    east: pooh,
    north: owl,
};
var bees = {
    character: "Bees",
    west: pooh,
    north: rabbit,
};
var owl = { 
    character: "Owl",
    south: piglet,
    east: robin,
};
var robin = {
    character: "Christopher Robin",
    south: pooh,
    north: kanga,
    west: owl,
    east: rabbit,
};
var rabbit = {
    character: "Rabbit",
    south: bees,
    east: gopher,
    west: robin,
};
var gopher = {
    character: "Gopher",
    west: rabbit,
};
var kanga = {
    character: "Kanga",
    south: robin,
    north: eeyore,
};
var eeyore = {
    character: "Eeyore",
    south: kanga,
    east: heff,
};
var heff = {
    character: "Heffalumps",
    west: eeyore,
}; 

var player = {
    location: tigger,
};

function move(direction){
    if (direction == "east"){
            player.location = player.location.east;
            console.log("You are now at " + player.location.character + "\'s house.");
    }
    if (direction == "west"){
        player.location = player.location.west;
        console.log("You are now at " + player.location.character + "\'s house.");
    }
    if (direction == "north"){
        player.location = player.location.north;
        console.log("You are now at " + player.location.character + "\'s house.");
    }
    if (direction == "south"){
        player.location = player.location.south;
        console.log("You are now at " + player.location.character + "\'s house.");
    }
};

